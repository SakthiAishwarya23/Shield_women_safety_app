package com.example.saftey_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Imageswitchs extends AppCompatActivity {
    private int[] images = {R.drawable.lightgreen, R.drawable.fram2, R.drawable.green};
    private int currentIndex = 0;
    private ImageSwitcher imageSwitcher;
    private WebView webView;


    private Button nextbutton;
    private Button playButton;
    private String videoId = "your_youtube_video_id"; // Replace this with your YouTube video ID


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imageswitchs);
        webView = findViewById(R.id.webView);
        playButton = findViewById(R.id.playButton);
        nextbutton = findViewById(R.id.nextbutton);


        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(getApplicationContext());
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                return imageView;
            }
        });
        imageSwitcher.setImageResource(images[currentIndex]);

        // Set OnClickListener for the ImageView to switch images
        ImageView imageView = findViewById(R.id.imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentIndex = (currentIndex + 1) % images.length;
                imageSwitcher.setImageResource(images[currentIndex]);
            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playYouTubeVideo();
            }
        });

        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Imageswitchs.this,Login_user.class);
                startActivity(intent);
            }
        });

        // Set up WebView settings
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
    }

    private void playYouTubeVideo() {
        String videoUrl = "https://www.youtube.com/watch?v=KVpxP3ZZtAc" + videoId;
        webView.loadUrl(videoUrl);
    }
}