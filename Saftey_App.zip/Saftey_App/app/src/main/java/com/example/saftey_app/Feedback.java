package com.example.saftey_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;
import android.widget.SeekBar;
import android.widget.TextView;

public class Feedback extends AppCompatActivity {
    private RatingBar ratingBar;
    private SeekBar efficiencySeekBar;
    private Button button7;
    private TextView efficiencyTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        ratingBar = findViewById(R.id.ratingBar);
        button7 = findViewById(R.id.button7);

        // Set a rating change listener to handle the user's rating selection
        ratingBar.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {
            // Handle the user's rating selection here
            String message = "You rated: " + rating + " stars";
            Toast.makeText(Feedback.this, message, Toast.LENGTH_SHORT).show();
        });

        efficiencySeekBar = findViewById(R.id.efficiencySeekBar);
        efficiencyTextView = findViewById(R.id.efficiencyTextView);

        // Set a SeekBar change listener to handle progress changes
        efficiencySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Handle progress changes here
                efficiencyTextView.setText("Efficiency: " + progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Called when the user starts interacting with the SeekBar
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Called when the user stops interacting with the SeekBar
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Feedback.this,Optionsmenubars.class);
                startActivity(intent);
            }
        });
    }
}