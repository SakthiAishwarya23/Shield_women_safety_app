package com.example.saftey_app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;

public class Information extends AppCompatActivity {
    private CheckBox checkBox3, checkBox5;
    private Button button2, button3,btn4;
    private TextView textView7;
    private TextView textView5;
    private TextView textView10;
    private RadioGroup RadioGroup;
    private ImageView imageView3;

    SharedPreferences.Editor editor;


    private RadioButton radioButton, radioButton2;
    private DatePickerDialog datepickerDialog;
    private Button dateButton;

    private TextView textViewTime;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        SharedPreferences sharedpreferences = getSharedPreferences("pref" , 0);
        int radio = sharedpreferences.getInt("status",3);
        editor = sharedpreferences.edit();
        RadioGroup = findViewById(R.id.RadioGroup);
        radioButton2 = findViewById(R.id.radioButton2);
        radioButton = findViewById(R.id.radioButton);
        if(radio ==1){
            radioButton2.setChecked(true);
        }else if(radio == 0){
            radioButton.setChecked(true);
        }


        RadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.RadioGroup group , int checkedId) {
                if(checkedId == R.id.radioButton2){
                    editor.putInt("status",1);
                }else if(checkedId ==R.id.radioButton){
                    editor.putInt("status",0);
                }
                editor.commit();
            }
        });

        checkBox3 = findViewById(R.id.checkBox3);
        checkBox5 = findViewById(R.id.checkBox5);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        textView7 = findViewById(R.id.textView7);
        textView5 = findViewById(R.id.textView5);
        textView10 = findViewById(R.id.textView10);
        RadioGroup = findViewById(R.id.RadioGroup);
        textViewTime = findViewById(R.id.textViewTime);
        imageView3 = findViewById(R.id.imageView3);




        btn4 = findViewById(R.id.btn4);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder result = new StringBuilder();
                result.append("You Selected:");
                if (checkBox3.isChecked()) {
                    result.append((" Send Location,"));
                }
                if (checkBox5.isChecked()) {
                    result.append((" Call \n"));
                }

                textView7.setText(result.toString());

                int ID = RadioGroup.getCheckedRadioButtonId();
                radioButton = findViewById(ID);
//               radioButton2=findViewById(ID);
                textView10.setText("You Selected: " + radioButton.getText());


            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(v, "Successfull", Snackbar.LENGTH_SHORT)
                        .setBackgroundTint(Color.parseColor("#00afb9"))
                        .setAnimationMode(BaseTransientBottomBar.ANIMATION_MODE_FADE).show();
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              Intent intent = new Intent(Information.this,Imageswitchs.class);
              startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });

        Button btnShowTimePicker = findViewById(R.id.btnShowTimePicker);
        btnShowTimePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });

        calendar = Calendar.getInstance();






    }
    private void openDialog() {
        DatePickerDialog dialog = new DatePickerDialog(this , R.style.DialogTheme,new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker , int year , int month , int day) {
                textView5.setText(String.valueOf(year)+"."+ String.valueOf(month+1)+"."+String.valueOf(day));
            }
        } , 2023 , 7 , 21);
        dialog.show();
    }
    private void showTimePickerDialog() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this, R.style.DialogTheme,new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);

                        updateTimeTextView();
                    }
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
        );
        timePickerDialog.show();
    }

    private void updateTimeTextView() {
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String timeString = sdf.format(calendar.getTime());
        textViewTime.setText(timeString);
    }



}
