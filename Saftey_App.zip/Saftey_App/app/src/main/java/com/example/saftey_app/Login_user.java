package com.example.saftey_app;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.Switch;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.ToggleButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class Login_user extends AppCompatActivity {
    public Button button1;
    private Spinner ageSpinner;
    private CameraManager cameraManager;
    private String cameraId;
    private Switch flashSwitch;
    private ImageView imageView2;
    private static final int REQUEST_CONTACTS_PERMISSION = 1;
    private ToggleButton contactToggleButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_user);
        imageView2 = findViewById(R.id.imageView2);
        flashSwitch = findViewById(R.id.flashSwitch);

        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            flashSwitch.setEnabled(false);
            return;
        }

        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        try {
            cameraId = getCameraIdWithFlash();
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        flashSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            try {
                setFlashMode(isChecked);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        });

        contactToggleButton = findViewById(R.id.contactToggleButton);

        // Set initial toggle state based on permissions
        boolean hasContactsPermission = hasContactsPermission();
        contactToggleButton.setChecked(hasContactsPermission);

        // Handle toggle state changes
        contactToggleButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                requestContactsPermission();
            } else {
                // Handle the case when the user toggles off the toggle button
                // You can clear contacts-related data or functionality here
            }
        });



        Button showDialogButton = findViewById(R.id.show_dialog_button);
        showDialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlertDialog();
            }
        });
        View yourBottomSheetView = findViewById(R.id.sheet1); // Replace with your BottomSheet's view ID


        BottomSheetBehavior<View> bottomSheetBehavior = BottomSheetBehavior.from(yourBottomSheetView);
        bottomSheetBehavior.setPeekHeight(200);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

        FloatingActionButton fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Add your action here when the FAB is clicked
                Toast.makeText(Login_user.this, "FAB clicked", Toast.LENGTH_SHORT).show();
            }
        });

        ageSpinner = findViewById(R.id.ageSpinner);

        // Create an array of age options
        String[] ageOptions = new String[100]; // For example, from 1 to 100
        for (int i = 0; i < 100; i++) {
            ageOptions[i] = String.valueOf(i + 1);
        }

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, ageOptions);

        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        ageSpinner.setAdapter(adapter);

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login_user.this,Feedback.class);
                startActivity(intent);
            }
        });



    }
    private void showAlertDialog() {
        // Create an AlertDialog.Builder instance
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Set the title and message for the dialog
        builder.setTitle("Would You Like To Submit");
        builder.setMessage("This Activity contains Confidential Information");

        // Add buttons and define their actions
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do something when the OK button is clicked
                dialog.dismiss(); // Close the dialog
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Do something when the Cancel button is clicked
                dialog.dismiss(); // Close the dialog
            }
        });

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private String getCameraIdWithFlash() throws CameraAccessException {
        String[] cameraIds = cameraManager.getCameraIdList();
        for (String id : cameraIds) {
            CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
            Boolean hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (hasFlash != null && hasFlash) {
                return id;
            }
        }
        return null;
    }

    private void setFlashMode(boolean isEnabled) throws CameraAccessException {
        if (cameraId != null) {
            cameraManager.setTorchMode(cameraId, isEnabled);
        }
    }

    private boolean hasContactsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestContactsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, REQUEST_CONTACTS_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode , permissions , grantResults);
        if (requestCode == REQUEST_CONTACTS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, update toggle state accordingly
                contactToggleButton.setChecked(true);
                // You can perform contacts-related operations here
            } else {
                // Permission denied, update toggle state accordingly
                contactToggleButton.setChecked(false);
                // You can handle the case when the user denies permission here
                Toast.makeText(this , "Contacts permission denied" , Toast.LENGTH_SHORT).show();
            }
        }
    }


}